﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Translation : MonoBehaviour {

    private float AngularVelocity = 0;
    // Use this for initialization
    void Start()
    {
        AngularVelocity = Random.Range(-20, 20);
    }
    // Update is called once per frame
    void Update()
    {
        transform.RotateAround(Vector3.zero, Vector3.up, (AngularVelocity * Time.deltaTime)* -0.10f);
    }
}
