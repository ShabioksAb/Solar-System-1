﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class navegation : MonoBehaviour {

    public NavMeshAgent nave;
    public Transform objetivo;

	void Start () {
    if(nave == null)
        {
            nave = this.gameObject.GetComponent<NavMeshAgent>();
        }		
	}
	
	// Update is called once per frame
	void Update () {
        nave.SetDestination(objetivo.position);
	}
}
